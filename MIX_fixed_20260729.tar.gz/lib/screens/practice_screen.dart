import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../providers/app_state.dart';
import '../widgets/error_cause_dialog.dart';
import 'stats_screen.dart';
import 'subject_management_screen.dart';

/// 刷题页 — 嵌入 PageView 中
///
/// 流程：看题思考 → 点"提交" → 显示答案+解析 → 自评"我答对了/我答错了" → 错因(如错)
class PracticeScreen extends StatefulWidget {
  const PracticeScreen({super.key});

  @override
  State<PracticeScreen> createState() => _PracticeScreenState();
}

class _PracticeScreenState extends State<PracticeScreen> {
  bool _showAnswer = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final state = context.read<AppState>();
      if (state.currentQuestion == null) {
        state.loadNextQuestion();
      }
    });
  }

  /// 用户自评：答对 or 答错
  Future<void> _selfRate(BuildContext context, bool correct) async {
    final appState = context.read<AppState>();
    String? mainCause;
    String? minorCause;

    if (!correct) {
      final result = await showDialog<ErrorCauseResult>(
        context: context,
        barrierDismissible: false,
        builder: (_) => const ErrorCauseDialog(),
      );
      if (result == null) return; // 取消
      mainCause = result.mainCause;
      minorCause = result.minorCause;
    }

    await appState.submitAnswer(
        correct: correct, mainCause: mainCause, minorCause: minorCause);
    setState(() => _showAnswer = false);
    await appState.loadNextQuestion();
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<AppState>(
      builder: (context, appState, _) {
        final question = appState.currentQuestion;

        if (appState.loadingNext && question == null) {
          return const Center(
              child: CircularProgressIndicator(color: Color(0xFFFF8C42)));
        }
        if (appState.lastError != null) {
          return _ErrorView(message: appState.lastError!);
        }
        if (question == null) {
          return const Center(
              child: Text('暂无题目',
                  style: TextStyle(color: Colors.white70, fontSize: 16)));
        }

        return Container(
          color: const Color(0xFF1A1A2E),
          child: Column(
            children: [
              // 顶部信息栏
              _buildHeader(appState),
              // 题干 + 答案
              Expanded(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        question['content'] as String? ?? '',
                        style: const TextStyle(
                            color: Colors.white, fontSize: 17, height: 1.6),
                      ),
                      if (_showAnswer) ...[
                        const SizedBox(height: 24),
                        const Divider(color: Colors.white12),
                        const SizedBox(height: 12),
                        const Text('参考答案',
                            style: TextStyle(
                                color: Color(0xFFFF8C42),
                                fontSize: 16,
                                fontWeight: FontWeight.bold)),
                        const SizedBox(height: 8),
                        Container(
                          width: double.infinity,
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: const Color(0xFF0F3460),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Text(
                            question['answer'] as String? ?? '',
                            style: const TextStyle(
                                color: Colors.white70, height: 1.5),
                          ),
                        ),
                        // 解析（题目系数展示）
                        if (question['cplx_coef'] != null) ...[
                          const SizedBox(height: 12),
                          Text(
                            '复杂度${_fmt(question['cplx_coef'])} · '
                            '理解${_fmt(question['und_coef'])} · '
                            '冗余${_fmt(question['red_coef'])} · '
                            '覆盖率${_fmt(question['cov_coef'])}',
                            style: const TextStyle(
                                color: Colors.white24, fontSize: 12),
                          ),
                        ],
                      ],
                    ],
                  ),
                ),
              ),
              // 底部操作区
              _buildBottomBar(appState),
            ],
          ),
        );
      },
    );
  }

  Widget _buildHeader(AppState appState) {
    return Container(
      padding: const EdgeInsets.all(16),
      color: const Color(0xFF16213E),
      child: Row(
        children: [
          Container(
            padding:
                const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: const Color(0xFFFF8C42).withValues(alpha: 0.2),
              borderRadius: BorderRadius.circular(20),
            ),
            child: const Text('刷题模式',
                style: TextStyle(color: Color(0xFFFF8C42), fontSize: 14)),
          ),
          const Spacer(),
          Text('第 ${appState.questionIndex} 题',
              style: const TextStyle(color: Colors.white54, fontSize: 14)),
          PopupMenuButton<String>(
            icon: const Icon(Icons.more_horiz,
                color: Colors.white38, size: 20),
            color: const Color(0xFF16213E),
            onSelected: (value) {
              if (value == 'stats') {
                Navigator.of(context).push(MaterialPageRoute(
                  builder: (_) => const StatsScreen(),
                ));
              } else if (value == 'subjects') {
                Navigator.of(context).push(MaterialPageRoute(
                  builder: (_) => const SubjectManagementScreen(),
                ));
              }
            },
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'subjects', child: Text('科目管理')),
              PopupMenuItem(value: 'stats', child: Text('学习统计')),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildBottomBar(AppState appState) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
      child: Column(
        children: [
          if (!_showAnswer)
            // 阶段1：提交看答案
            SizedBox(
              width: double.infinity,
              height: 48,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFFF8C42),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12)),
                ),
                onPressed: () => setState(() => _showAnswer = true),
                child: const Text('提交 / 看答案',
                    style: TextStyle(color: Colors.white, fontSize: 16)),
              ),
            )
          else ...[
            // 阶段2：自评对错
            Row(
              children: [
                Expanded(
                  child: SizedBox(
                    height: 48,
                    child: OutlinedButton(
                      style: OutlinedButton.styleFrom(
                        side: const BorderSide(color: Color(0xFFFF6B6B)),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12)),
                      ),
                      onPressed: appState.loadingNext
                          ? null
                          : () => _selfRate(context, false),
                      child: const Text('我答错了',
                          style: TextStyle(
                              color: Color(0xFFFF6B6B), fontSize: 16)),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: SizedBox(
                    height: 48,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF4ECDC4),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12)),
                      ),
                      onPressed: appState.loadingNext
                          ? null
                          : () => _selfRate(context, true),
                      child: const Text('我答对了',
                          style: TextStyle(color: Colors.white, fontSize: 16)),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ],
      ),
    );
  }

  String _fmt(dynamic v) {
    if (v == null) return '-';
    return (v as num).toStringAsFixed(2);
  }
}

class _ErrorView extends StatelessWidget {
  const _ErrorView({required this.message});
  final String message;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.info_outline, size: 48, color: Colors.white38),
            const SizedBox(height: 12),
            Text(message,
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.white70)),
            const SizedBox(height: 16),
            OutlinedButton(
              onPressed: () => context.read<AppState>().loadNextQuestion(),
              child: const Text('重试'),
            ),
          ],
        ),
      ),
    );
  }
}
